# plugin.rtvslo.live #
## Description / Opis ##

Audio/video plugin (add-on) for Kodi. It plays audio and video streams published by RTV Slovenija.  
Avdio/video vtičnik (add-on) za Kodi. Predvaja avdio in video kanale objavljene na spletnem portalu RTV Slovenija.

## Setup / Namestitev ##
Download file as ".zip" (plugin.rtvslo.live-master), then install plugin via Kodi interface.  
Prenesi ".zip" datoteko (plugin.rtvslo.live-master), nato namesti preko Kodi vmesnika.

## Author: / avtor: dam-pav 
Suggestions and advice welcome.  
Predlogi in nasveti so dobrodošli.

## Note / Opomba ##
Stay tuned for more ;-)
