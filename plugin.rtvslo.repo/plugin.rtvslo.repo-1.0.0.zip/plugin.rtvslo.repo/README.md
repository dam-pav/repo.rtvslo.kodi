# plugin.rtvslo.repo
Namestitev Kodi dodatkov za predvajanje vsebin RTV Slovenija  
Installation of Kodi add-ons for playing content from RTV Slovenija

**About the repository / O repozitoriju**  
Download and install add-ons for Kodi in the category "All" using RTV Slovenija.  
Snemite in namestite dodatke za Kodi v kategoriji "All" pod RTV Slovenija

**Disclaimer / Odgovornosti**  
The software is provided as-is and comes with no warranty whatsoever. The author of the software does not provide the media content nor does he gain from its consumption. All responsibility for the comsumption lies with the consumer.  
Programska oprema je kakršna je, brez kakršnekoli garancije. Avtor programske opreme ne zagotavlja medijske vsebine, niti nima nikakršne koristi pvezane z njenim predvajanjem. Vse odgovornosti prevzema končni uporabnik medijskih vsebin.  
